import React, { useState } from 'react';
import {
  AppBar, Toolbar, Typography, Container, Grid, Card, CardContent, Button, Box,
  Drawer, List, ListItem, ListItemIcon, ListItemText, IconButton, TextField,
  Switch, Snackbar, Alert, Fab, Dialog, DialogTitle, DialogContent, DialogContentText,
  DialogActions, CircularProgress, LinearProgress, Chip, Avatar, Divider
} from '@mui/material';
import {
  Menu as MenuIcon,
  Home as HomeIcon,
  Info as InfoIcon,
  Mail as MailIcon,
  Add as AddIcon,
} from '@mui/icons-material';
import Autocomplete from '@mui/material/Autocomplete';
import LocationList from './LocationList';
import CardActions from '@mui/material/CardActions';
import Stack from '@mui/material/Stack';
import './App.css';

function Header() {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const toggleDrawer = (open) => () => {
    setDrawerOpen(open);
  };

  const drawerContent = (
    <Box sx={{ width: 250 }} role="presentation" onClick={toggleDrawer(false)}>
      <List>
        {['Home', 'About', 'Contact'].map((text, index) => (
          <ListItem button key={text}>
            <ListItemIcon>{index === 0 ? <HomeIcon /> : index === 1 ? <InfoIcon /> : <MailIcon />}</ListItemIcon>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <IconButton edge="start" color="inherit" aria-label="menu" onClick={toggleDrawer(true)}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Air Quality Checker
          </Typography>
          <Button color="inherit">Contact</Button>
        </Toolbar>
      </AppBar>
      <Drawer anchor="left" open={drawerOpen} onClose={toggleDrawer(false)}>
        {drawerContent}
      </Drawer>
    </Box>
  );
}

function Information(){
    return (
      <Card sx={{ minWidth: 275 }}>
        <CardContent>
          <Typography variant="h5" component="div">
            Recommended Air Quality Standards
          </Typography>
          <br></br>
          <Typography variant="body2">
            [Insert List of standards here]
            <br />

          </Typography>
        </CardContent>
        <CardActions>
          <Button size="small">Learn More</Button>
        </CardActions>
      </Card>
    );
  }

function Search() {
  return (
    <Autocomplete
      disablePortal
      options={LocationList}
      sx={{ width: 300, margin: 'auto' }}
      renderInput={(params) => <TextField {...params} label="Country" />}
    />
  )
}

function Footer() {
  return (
    <Box component="footer"
      alignItems="center"
      display="flex"
      justifyContent="center"
      flexDirection={'column'}
      sx={{
        backgroundColor: 'primary.dark',
        color: 'white',
        py: 3,
        mt: 'auto',
        textAlign: 'center'
      }}>
      <Typography>PWC 2024</Typography>
      <List>
        <ListItem button>Prattay Banik</ListItem>
        <ListItem button>Christine Bong</ListItem>
        <ListItem button>William Bakos</ListItem>
      </List>
    </Box>
  )
}

function App() {
  return <>
    <Header></Header>
    <Box sx={{backgroundColor: '#DAF0EE'}}>
    <Information></Information>
      <Container maxWidth="sm">
        <Box sx={{ mb: 4}}>
          <Search></Search>
        </Box>
      </Container>
      <Footer></Footer>
    </Box>
  </>

}

export default App;