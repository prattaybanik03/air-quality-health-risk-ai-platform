import React, { useState } from 'react';
import {
  AppBar, Toolbar, Typography, Container, Card, CardContent, Button, Box,
  Drawer, List, ListItem, ListItemIcon, ListItemText, IconButton, TextField,
} from '@mui/material';
import {
  Menu as MenuIcon,
  Home as HomeIcon,
  Info as InfoIcon,
  Mail as MailIcon,
} from '@mui/icons-material';
import Autocomplete from '@mui/material/Autocomplete';
import LocationList from './LocationList';
import CardActions from '@mui/material/CardActions';
import Stack from '@mui/material/Stack';
import './App.css';

function Header() {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const toggleDrawer = (open) => () => {
    setDrawerOpen(open);
  };

  const drawerContent = (
    <Box sx={{ width: 250 }} role="presentation" onClick={toggleDrawer(false)}>
      <List>
        {['Home', 'About', 'Contact'].map((text, index) => (
          <ListItem button key={text}>
            <ListItemIcon>{index === 0 ? <HomeIcon /> : index === 1 ? <InfoIcon /> : <MailIcon />}</ListItemIcon>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
    </Box>
  );

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <IconButton edge="start" color="inherit" aria-label="menu" onClick={toggleDrawer(true)}>
            <MenuIcon />
          </IconButton>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Air Quality Checker
          </Typography>
          <Button color="inherit">Developer Team</Button>
        </Toolbar>
      </AppBar>
      <Drawer anchor="left" open={drawerOpen} onClose={toggleDrawer(false)}>
        {drawerContent}
      </Drawer>
    </Box>
  );
}

function Search() {
  const [selectedCountry, setSelectedCountry] = useState(''); // State to store selected value

  const handleSearchClick = () => {
  // This is where you handle what happens when the button is clicked
  console.log("Selected Country:", selectedCountry);
  // You can use the selectedCountry value for any logic you need here
};
  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 2,
      }}
    >
      <Autocomplete
        disablePortal
        options={LocationList}
        sx={{ width: 300 }}
        value={selectedCountry} // Bind value to the state
        onChange={(event, newValue) => setSelectedCountry(newValue)} // Update state on selection
        renderInput={(params) => <TextField {...params} label="Country" />}
      />
      <Button variant="contained" onClick={handleSearchClick}> {/* Handle button click */}
        Check Air Quality Data
      </Button>
    </Box>
  )
}


function Information(){
  return (
    <Card sx={{ minWidth: 275 }}>
      <CardContent>
        <Typography variant="h5" component="div">
          Why is your air quality important?
        </Typography>
        <br></br>
        <Typography variant="body2">
          Air quality has been found to be linked to numerous health risks among those including increased risks of cancer, respiratory conditions and immune system responses
          <br />
          {'"Why risk it?"'}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small">Learn More</Button>
      </CardActions>
    </Card>
  );
}

function Footer() {
  return (
    <Box component="footer"
      alignItems="center"
      display="flex"
      justifyContent="center"
      flexDirection={'column'}
      sx={{
        backgroundColor: 'primary.dark',
        color: 'white',
        py: 3,
        mt: 'auto',
        textAlign: 'center'
      }}>
      <Typography>PWC 2024</Typography>
      <List>
        <ListItem button>Prattay Banik</ListItem>
        <ListItem button>Christine Bong</ListItem>
        <ListItem button>William Bakos</ListItem>
      </List>
    </Box>
  )
}

function ImageDisplay() {
  return (
<Box
      sx={{
        position: 'relative',  
        width: '100%',
        height: 'auto',
        maxHeight: '50vh',
        overflow: 'hidden',    
      }}
    >
      {/* Image */}
      <Box
        component="img"
        sx={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
        }}
        src="CityPolluted.jpg"
        alt="Polluted City"
      />

       {/* Gradient Fade Effect */}
       <Box
        sx={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          background: 'linear-gradient(transparent, rgba(0, 0, 0, 0.7))', // Change RGBA value to change the colour you want the edges to fade to. Currently set to black
          pointerEvents: 'none',
        }}
      />

      {/* Overlapped Text */}
      <Box
        sx={{
          position: 'absolute',
          top: '50%', //alter these values to shift the text vertically/horizontally
          left: '50%',
          transform: 'translate(-50%, -50%)', 
          color: 'white',
          textAlign: 'center',
        }}
      >
        <Typography variant="h3" component="div" fontFamily={"inherit"}>
          Looks Familiar?
        </Typography>
        <Typography variant="subtitle1" component="div" fontFamily={"sans-serif"}>
          A wake-up call for environmental change, and your health
        </Typography>
      </Box>
    </Box>
  )
}


function App() {
  return <>
  <Box sx={{backgroundColor: '#DAF0EE'}}>
    <Header></Header>
      <Container maxWidth="sm">
        <Box sx={{ m: 4}}>
          <ImageDisplay></ImageDisplay>
        </Box>
        <Box sx={{ m: 4}}>
          <Search></Search>
        </Box>
        <Information></Information>
      </Container>
      <Footer></Footer>
    </Box>
  </>

}

export default App;