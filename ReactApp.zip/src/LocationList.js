const LocationList = [
    {label: 'Australia'},
    {label: 'Zimbabwe'},
    {label: 'Montenegro'},
];

export default LocationList;